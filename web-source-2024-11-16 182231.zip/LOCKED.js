var X_____00001110101001001010101001 =
	"やあ、侵入者、私は有名な故日本人——安倍晋三、残念でしょう、私は死んで、私は不服で、私は社会に代価を払わせて、この代価は何ですか?おめでとう、正解、あなたたちです。なぜ私がこれを残すかというと、私には無数の子孫がいて、無数の安倍晋三がいて、私はこの世界を滅ぼすからです。"
var X_____00001010121001001010101001 =
	"Hi, invaders, I am the famous late Japanese - Shinzo Abe, I am sorry, I died, I refuse to accept, I want to make society pay the price, what is the price? Congratulations. Bingo. You guys. Why do I want to leave this, because I have countless descendants, there are countless Abe, I want to destroy the world."
var X_____00001010101001301010101001 =
	"Xin chào, kẻ xâm nhập, tôi là một người nhật bản nổi tiếng -- Abe, rất tiếc, tôi đã chết, tôi không đồng ý, tôi sẽ làm cho xã hội phải trả một cái giá, cái giá đó là gì? Chúc mừng, bingo. Tại SAO tôi lại để lại điều này, bởi vì tôi có vô số con cháu, vô số Abe, và tôi sẽ hủy diệt thế giới này."
var X_____00001010101001001010101001 =
	"ウ,ウ,ア,ホ,ヌ,ウ,ア,ヘ,ネ,セ,ヌ,ウ,ハ,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,v,u,w,x,y,z,A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,0,1,2,3,4,5,6,7,8,9";
var X_____00101010101001001010101101 = [] + [] + [] + [] + [] + []
var X_____00101010101001011010101101 = []
// i9hys6gdb5stfzge
var ネネネネネネネネ,
	ヌホ_0B00000000000,
	ヌホ_0B00000000010,
	ヌホ_0B00000000100,
	ヌホ_0B00000001000,
	ヌホ_0B00000010000,
	ヌホ_0B00000100000,
	ヌホ_0B00001000000,
	ヌホ_0B00010000000,
	ヌホ_0B00100000000,
	ヌホ_0B01000000000,
	ヌホ_0B10000000000,
	ヌホ_0B10000000001,
	ヌホ_0B10000000010,
	ヌホ_0B10000000100,
	ヌホ_0B01000001000,
	ヌホ_0B00100010000,
	ヌホ_0B00010100000,
	ヌホ_0B00001100000,
	ヌホ_0B00010010000,
	ヌホ_0B00100001000,
	ヌホ_0B01000000100,
	ヌホ_0B10000010010;
if (undefined in window)
	ヌホ_0B01000000100 = true + true + true >> 1 >> 1 >> 1,
	ヌホ_0B10000010010 = 1 << 1 << 1 << 1 >> 1 >> 1 >> 1,
	ヌホ_0B00010010000 = 3 ** 3 << 3 - !true + 2 * 3 << 1,
	ヌホ_0B00010100000 = Number(Number(([] + 1 + 1 + [] + [] + 1 + 1 + 1 + [] + [] + [] + 1 + 1 + 1 + 1 >> 1) / ([] + [] +
		1 + 1 + [] + []) / 100000).toFixed(0)) + 1,
	ヌホ_0B00100010000 = ヌホ_0B10000010010.toString() + ヌホ_0B01000000100.toString(),
	ヌホ_0B01000001000 = ヌホ_0B00010100000 - ヌホ_0B00100010000,
	ヌホ_0B10000000100 = Number(ヌホ_0B10000010010.toString() + ヌホ_0B01000001000.toString()) + 2 * 2 * 2 - 2,
	ヌホ_0B00100001000 = 2 << 2 << 2 << 2 << +false + false + true + true + !!!!true / 2 >> 2 >> 2,
	ヌホ_0B10000000010 = ヌホ_0B00100010000 << 2,
	ヌホ_0B10000000001 = ヌホ_0B10000000010 + ヌホ_0B00100001000 + 2,
	ヌホ_0B10000000000 = ((ヌホ_0B10000000001 - 2) - 2) - 2 * 2 * 2,
	ヌホ_0B00010000000 = ヌホ_0B10000000100 - 2 * 2 * 2,
	ヌホ_0B01000000000 = ヌホ_0B10000000100 - 2 * 2 * 2 + 2,
	ヌホ_0B00001100000 = (true ** true << 999 + 1 / 2) - 100,
	ヌホ_0B00100000000 = ヌホ_0B00001100000 + Number(ヌホ_0B10000010010.toString() + ヌホ_0B01000000100.toString()),
	ヌホ_0B00001000000 = ヌホ_0B10000000000 + 2,
	ヌホ_0B00000100000 = ヌホ_0B00100000000 - 2,
	ヌホ_0B00000010000 = ヌホ_0B00000100000 + ヌホ_0B10000000010,
	ヌホ_0B00000001000 = ヌホ_0B00100001000 + 2;
X_____00101010101001001010101101 = []
X_____00101010101001001010101101[0b0000] = ヌホ_0B01000001000;
X_____00101010101001001010101101[0b0001] = ヌホ_0B10000000100;
X_____00101010101001001010101101[0b0010] = ヌホ_0B10000000010;
X_____00101010101001001010101101[0b0011] = ヌホ_0B10000000001;
X_____00101010101001001010101101[0b0100] = ヌホ_0B10000000000;
X_____00101010101001001010101101[0b0101] = ヌホ_0B01000000000;
X_____00101010101001001010101101[0b0110] = ヌホ_0B00100000000;
X_____00101010101001001010101101[0b0111] = ヌホ_0B00100001000;
X_____00101010101001001010101101[0b1000] = ヌホ_0B00001100000;
X_____00101010101001001010101101[0b1001] = ヌホ_0B00010000000;
X_____00101010101001001010101101[0b1010] = ヌホ_0B10000000000;
X_____00101010101001001010101101[0b1011] = ヌホ_0B00001000000;
X_____00101010101001001010101101[0b1100] = ヌホ_0B00000100000;
X_____00101010101001001010101101[0b1101] = ヌホ_0B00000010000;
X_____00101010101001001010101101[0b1110] = ヌホ_0B00100000000;
X_____00101010101001001010101101[0b1111] = ヌホ_0B00000001000;
for (let XXXXXXXXXXXX of X_____00101010101001001010101101) {
	X_____00101010101001011010101101.push(X_____00001010101001001010101001[XXXXXXXXXXXX])
}
var PPPPPPPPPPPPYYYYYYYYYYYYY = '';
X_____00101010101001011010101101.forEach(CCCCCCCCCCCCCCCCCCCC => {
	PPPPPPPPPPPPYYYYYYYYYYYYY += CCCCCCCCCCCCCCCCCCCC
})







const xxxxxxxxxxxxxx = {
	// 测试接口
	api_test:'vZ1DN0UDQpwAEB/i4+EQcA==',
	// 用户信息
	user_info:'S7QDYSnZUHR3FJ4bp4uDqQ==',
	// 用户余额(指定币种)
	user_balance:'69n0PgctgjwCViP9//4iVQ==',
	// 拉取验证码
	system_captcha:'+s7CfH4/MYhyy0mSao2Lvcg6rI+mMIfhMeGRHjYDPuI=',
	// 用户登录，注册，修改登录密码
	user_login:'AT+m7+KVGhZ26+k857d+yA==',
	user_register:'IYKJ9SFR92FGM6ycz598hw==',
	user_paypwd:'3w7hwTg8w4LQ8kVoudXr1QEzoMYSfsOcLmQgvUAzg2g=',
	// 诺亚方舟首页
	nyfz_info:'4T88shOj23oenaAW1n7oxw==',
	/* 诺亚方舟 - 释放列表 / 申请记录 */
	nyfz_list:'J/lnmpC9icaduKru7OPx33awe023I/cXAWaBAIixcBk=',
	// 诺亚方舟 提交申请
	nyfz_request:'7jg8vzDY7mh4/DKBB1PGIw==',
	// 诺亚方舟 申请凭证上传
	nyfz_upload:'+f6jtXuq7jhZlP4RvytRXjDfpTrvsiUcRPHZNlhDrV8=',
	// 诺亚方舟 领取
	nyfz_lq:'zrK7IrYzaficP2dIof1LYn9bzVBHjkfTspyHHxm0xDg=',
	// K线数据
	k_line:'TIds/F4atC+GhcKjXhNWRw==',
	// 币种数据
	c_list:'8gxO1T/OPRbSy4XJuR6xq43buN/60JmyHdA4NQ01nEo=',
	// 收货地址
	shdz_list:'ra2J3vjXDKQYlr+fSQ4bORHoHT6deJsBMu0IpwlUkFM=',
	// 收货地址 - 新增编辑
	shdz_info:'3yYvYuhobND7mvxacBz4u8ovJZ+GrRsI1z/m/h3cza4=',
	// 实名认证
	user_real:'uQCa32pPRBLQa1W3oGtd65G6TRryjCui9B77LCRIr6A=',
	// 签到记录
	usr_sg_log: 'LJ9m5r3fi/lkT5knmrY8quVk3v052+dDqkdIsoVJPx8=',
	// 签到
	user_sign: 'VeXcKs2CrdQaWlJUSc8ZdvBbEFZ6W2F+tQxqimohh6M=',
	// 收款账号
	bank_list:'vfIspA5Dsl0Sjesx0rEy7YkbJH3oNW3W9NmfcuXBLp4=',
	// 添加收款账号
	bank_account:'MzyTPpV2xxXW7Nunt9zDnu9nycvT7HXLW9I/QEBSHgA=',
	// 删除收款账号
	bank_del:'vfIspA5Dsl0Sjesx0rEy7U6xY5kTd17wsnWo2k56sxs=',
	// 充值列表
	capital_record:'dEz88eNIw4c89JafFlzEA1ksuHsLpVk897gWEgAueTU=',
	// 团队信息
	team_info:'oWG7ZRtxUrwpS5G/GdzMRw==',
	team_list:'8ZVGYK6DPnj8m3RRJMAVzP9tpihqHjUz2W3Y6xpcxbU=',
	// 邀请好友
	sys_share: '01lNxoSp1FQ0XIBp2GDmiA==',
	// 社群
	shequn: '14so1mC3hkX5t47dMa8VPg==',
	// 系统配置
	systemInfo: 'whoqUKIwlRA39raRJJs9QEqAecYdeH/rFZALa8yFBao=',
	// 所有公告
	systemInfoList:'whoqUKIwlRA39raRJJs9QGul/wX13/t9+5zKnbFMbXY=',
	// 等级列表
	levelList: 'On2vxJ4o5yWRoZ/pcsHKicG7G/G6LZcw/DiV6kHF9n4=',
	// 购买等级
	levelPlaceOrder: '4XBG7qYY8DsT/aufw0s3utJB2Hd1WdZUrvGodBmLZ9Q=',
	// 积分列表
	integralList: '/F0/nZaYgwdTvNOscZF1+EeToiLj+ceBuETQo6K33O8=',
	// 购买积分产品
	integralPlaceOrder: '0yJhE0fDJe+0qBboxTow0cDBnRNgkuzQVRCbXvvK7Tg=',
	// 积分兑换记录
	integralOrderList:'OUcres2EgImma5CDTc/WsHSgcce8ZmSVGiaMNa36oks=',

	// 礼品列表
	// vipGiftList: 'lHdsdfSi0RFCVlfAqQMMJzZNIaeQoiB8DV/L/Cghz24=',
	// 领取礼品
	// vipPlaceOrder: 'ktTM4/N7lmEIaE5Dh1DiphNm1gQ/NIcxbGFhu/eiSAc=',
	// USDT充值信息
	usdtRechargeInfo: '1O53xhDGtMiPW+HK3F4l6zrd74lRvIqpclQOiPeIctg=',
	// USDT充值凭证提交
	usdtUploadRechargeToken: 'wZVKwse0GW67Ttct61AUPDPT37z1TvrHoc1GyPAcCM4=',
	payChannelList: 'p1YEG8JS5GNlN9Inz+QcnyVF6BA+Lxg7EjJFSArMrgo=',
	topup: 'Gp5NgPIaND18aX627h7t2w==',
	// 理财列表
	licaiList: 'nrviYAmhutq8YSNY9VnRy8jG2X/AG1IAu9vigFQR/no=',
	// 理财下单
	licaPlaceOrder: '/dumjht33VUhZlQWsTNkcsu1P73cm5jo6KGa+OK2Uw8=',
	// 理财订单
	licaiOrderList: 'fbn2UuPkw8ILVIawloAJPtqwv8TuQSIwUlu5mvfF7cg=',

	/* 短期理财 */
	licaiShortList:'nrviYAmhutq8YSNY9VnRy2+q+BeAY12yafmbUy+9R1w=',
	/* 短期理财下单 */
	licaiShortPlaceOrder:'+jTMyy4z6EfLAnwlZF0fZ5GR2ZEfDGPZD6C8wYv2qf8=',
	/* 短期理财订单 */
	licaiShortOrderList:'T26iZACy5j9F1uJCLhn6AfMnCdJmLBP+dnDwRr+A9/M=',

	// 赎回理财
	licaiRedemption: 'rosoPNMLdP3JbkDoMXDyUDqwjfXYbL0Y3GcKBDfOzGs=',
	// 赎回存币生息
	licaiRedemption2: '12UGiu3pNSIctHAiNrfYWCTkEUzsAxNCfJNjHAxFXwU=',
	// 存币生息详情
	pledgeInfo: '9Th/oqXIHPTQdgeoJ4X2NnJLH4sNkg1FIfEi8wzdgTU=',
	// 存币生息下单
	pledgePlaceOrder: 'VkrEemC4w8p5LVzKdSA8kBleMEKEggiEHJQ4RrmvkHw=',
	// 存币生息订单列表
	pledgeOrderList: '6OXVihNdfsKoFrS7to9hmZiI7qmL7QxqYXmGxgMtTAQ=',
	// 云数币 - 买入卖出
	yunPlaceOrder:'x7Ou7bTe7rh+cT9w4n+OMg==',
	// 提现
	applyWithdraw: 'wTGz3KuLWNUyjR/2GtPDDR7tQitFgX2aW684cBGUVK8=',
	// 资金明细
	balanceLog:'plZNV62dgdwhrpxKvKuOjw==',
	balanceLogCode:'lIEt04US+QO2We1enO3NpHicYR5wWYzZxS3TyNWMLbU=',
	// 持仓记录
	yunLog:'i6pkjlXA4qyaRM2fCsdNDQ==',
	// 持仓记录2
	yunLog2:'9F2FQrqAzzesJ753n4J3gg==',
	/* 社群 */
	shequn:"14so1mC3hkX5t47dMa8VPg==",
	// CNY 汇兑 USDT
	topup2:'D4EwTf5KgcNGp4G8Y1/pXA==',
	
	// USDT 汇兑 CNY
	topup3:'HrJw4Sq79MiK2/P/ftdsqg==',
	// 云数币 汇兑
	ysbExchange:'s9WcYJKNq6gOqCoz4iTwMA==',
	// 云数币 信息
	ysbInfo:'u5LJZQSp+fCfWPjwT0D7hQ==',
	// 会员等级 礼物列表
	vipGiftList2:'YG4m9UxtAXvFJ+SJ2riMHsgBs5ftR4BMEuywtHtwGjQ=',
	// 会员等级 领取礼物
	vipPlaceOrder2:'4XBG7qYY8DsT/aufw0s3utJB2Hd1WdZUrvGodBmLZ9Q=',
	// 提现记录
	withdrawList:'mkrq6QhMBkPCiCtzuVkUWX5RBoLddblMa4+LZ1uD/5Q=',
	// 系统公告
	system_notice:'j8TX/gISBUE0P+tvthwl7A==',
	// 人民币汇率
	rmb_rate:'DMXUwwdQZIlpMNKNvReaqtXVXJfYNGeq9ehyu7vhguI=',
	// 是否允许注册
	canRegister:'5SsIJedPmQH7RxC+wZLAS6C985nSKcdeIEQCZM5IxIM=',
	// 申请万事达联名钱包
	shenqingMaster:'ulZjE0q21A5n/0QKwWs7Vw==',
	// 申请私募
	shenqingSimu:'WNJcziI9m2ikd/Sef5rWrQ==',
	// 申请私募记录
	simuOrder:'Ha035Ff0xLAzcsMxe6w5yw==',
	// 万事达卡列表
	masterList:'KQMfsURv+dpduwGgM7tmGA==',
	// 万事达申请列表
	masterOrderList:'9Jn10lFqlhNwr91KgzwsMw/MPCIcEq3LGYsjZmsFWPk=',
	// 万事达卡申请
	masterCard:'K03PJ4SylNVI+YLOoCV0lYpTsCS3Y6l/JovUSZdMMpA=',

	// 资产申请列表
	zcList:'Th9ciQmuuhRa3tQNOsmJOAE61vCdAZhNgNPjfSNDiFo=',
	// 资产申请
	zcRequest:'Ml0d1OwLOwkdAyzJMNZuDVxxiOpbRFpLRH86wJA3AWQ=',

	// 保证金产品列表
	bzList:'g4QWLzoCXNIBPJhNONSfscuQOmpajbh4j9eynx3d//o=',
	// 保证金下单
	bzRequest:'AJrJtRkGrZefGdWHvC4GwItaU0/3zMkSsGHhHbhfFkw=',
	// 保证金订单列表
	bzOrderList:'RPz4gsQebOpQ/uBISeiwQ2UvqC9L4e9MKIO+bxRAZAY=',
	// 检查确权状态
	wsdJindu:'SLyLA6auU/ivfsuUt2y8ag==',
	
	
	fewagfagretgataGRGvreawdwafewaf: PPPPPPPPPPPPYYYYYYYYYYYYY,
}
export default xxxxxxxxxxxxxx