<template>
	<view>
		<image style="width: 100%;" src="../../static/images/home/zcwj.jpg" mode="widthFix"></image>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			};
		}
	}
</script>

<style lang="scss">

</style>
